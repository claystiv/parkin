<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Parqueadero extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('parqueadero_model');
    }

    public function index()
    {
        $data['vehiculos'] = $this->parqueadero_model->get_vehiculos();
        $this->load->view('parqueadero/listar_vehiculos', $data);
    }

    public function ingresar_vehiculo()
    {
        $this->load->view('parqueadero/ingresar_vehiculo');
    }

    public function guardar_vehiculo()
    {
        $data = array(
            'placa' => $this->input->post('placa'),
            'conductor' => $this->input->post('conductor'),
            'tiempo_uso' => $this->input->post('tiempo_uso')
        );

        $this->parqueadero_model->guardar_vehiculo($data);

        redirect('parqueadero');
    }

    public function editar_vehiculo($id)
    {
        $data['vehiculo'] = $this->parqueadero_model->get_vehiculo($id);
        $this->load->view('parqueadero/editar_vehiculo', $data);
    }

    public function actualizar_vehiculo($id)
    {
        $data = array(
            'placa' => $this->input->post('placa'),
            'conductor' => $this->input->post('conductor'),
            'tiempo_uso' => $this->input->post('tiempo_uso')
        );

        $this->parqueadero_model->actualizar_vehiculo($id, $data);

        redirect('parqueadero');
    }

    public function eliminar_vehiculo($id)
    {
        $this->parqueadero_model->eliminar_vehiculo($id);

        redirect('parqueadero');
    }
}

<?php

namespace App\Models;

use CodeIgniter\Model;

class ParqueaderoModel extends Model
{
    protected $table = 'vehiculo'; 
    
    protected $allowedFields = ['placa', 'conductor', 'tiempo_uso']; 
}
